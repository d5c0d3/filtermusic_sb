﻿package Plugins::FilterMusic::Plugin;

#########################################################################
# Plugin: FilterMusic                                                   #
#                                                                       #
# Version: 0.2                                                          # 
#                                                                       #
# Release Date: 2011-10-10                                              #
#                                                                       #
# Website: http://code.google.com/p/filtermusic/                        #
#                                                                       #
# Author: Denny Schanze (d5c0d3 at gmail dot com)                       #
#                                                                       #
# Credits: Triode (http://forums.slimdevices.com/member.php?u=17)       #
#          for helping me converting my perl-script in a plugin         #
#                                                                       #
# Purpose:                                                              #
#  I am a big fan of FilterMusic.net <http://www.filtermusic.net>       #
#  where a selection of links to internet radio stations streaming with #
#  high(er) bitrate (>128kbps) is hosted.                               #
#  To be able to browse FilterMusic with my Squeezebox Server and       #
#  Players I programmed a perl script that would create an              #
#  OPML-Playlist. Because FilterMusic is updated on a regular basis     #
#  I would have to run this script quite often. To dynamically browse   #
#  the playlist I developed this plugin.                                #
#                                                                       #
# Copyright:                                                            #
#  Feel free to use my script to improve it's functionality or to       #
#  develop your own script/plugin. All I ask you to refer to my script  #
#  and let me know.                                                     #
######################################################################### 

use strict;

use base qw(Slim::Plugin::OPMLBased);
use HTML::TreeBuilder;
use Slim::Formats::XML;

use Slim::Utils::Log;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.filtermusic',
	'defaultLevel' => 'ERROR',
	'description'  => getDisplayName(),
});

sub initPlugin {
	my $class = shift;

	# this creates a new menu in the radios menu tree
	$class->SUPER::initPlugin(
		feed   => \&toplevel,
		tag    => 'filtermusic',
		menu   => 'radios',
		is_app => 0,
		weight => 10,
	);
}

sub getDisplayName { 'PLUGIN_FILTERMUSIC' }

# this ensures the menu is in the radio menu on some player types
sub playerMenu { 'RADIO' }

#need to define title list for 'newly added' menu globally;
my @title_list = ();
						
# this is called when the user browses into the menu
sub toplevel {
	my ($client, $callback, $args) = @_;

	my $url = "http://www.filtermusic.net/accordion";
	
	my $rss = "http://www.filtermusic.net/feed";
	
	# A list of new radio stations taken from the FilterMusic RSS feed
	# use server framework for async http fetch
	Slim::Networking::SimpleAsyncHTTP->new(
		
		#fetch success
		sub {
			my $xml = shift;
			
			my $xmltree = HTML::TreeBuilder->new;
			$xmltree->parse_content($xml->content);
			
			@title_list = $xmltree->look_down("_tag", "title");
		},
		
		#fetch failure - send back the error
		sub {
			$log->warn("error: $_[1]");
			#$callback->([ { name => $_[1], type => 'text' } ]);
		},
	)->get($rss);
	
	# use server framework for async http fetch
	Slim::Networking::SimpleAsyncHTTP->new(
		
		#fetch success
		sub {
			my $http = shift;
			$log->debug("HTML tree: " . $http->content);
			
			my $tree = HTML::TreeBuilder->new;
			$tree->parse_content($http->content);

			# from here we want to find the radiostations in the HTML tree
			# and create the necessary XML tags

			# first look for all <h2> tags with the class attribute set to 'display'
			# here the different style categories are defined (Lounge, Hip-Hop, etc.)
			my @category_list = $tree->look_down("_tag", "h2", "class", "display");
			
			# look for all <div> tags with class 'stretcher'
			# which contains all radio stations
			my @stretcher_list = $tree->look_down("_tag", "div", "class", "stretcher");

			my @category_menu = ();
			my @newly_added_menu = ();
						
			
			# repeat loop for all categories
			my $index = 0;
			foreach my $categories (@category_list) {
			
				# there is an entry in the list with 'id' attribute set to 'INTRO'
				# which doesn't contain any radiostation, so we skip that
				if (my $category = $categories->attr("title")){
					
					$log->debug("category: $category");
			
					# only the radiostatios that belong to the current category
					foreach my $stretcher ($stretcher_list[$index]) {
						# each category contains a list of radiostations
						my @radio_list = $stretcher->look_down("_tag", "li");
						
						my @radio_list_menu = ();
						
						# repeat loop for all radiostations under the current category
						foreach my $radio (@radio_list){
							
							# the current radiostation
							my $station = $radio->look_down("_tag", "a");
							# the description of the current radio station
							my @description = $radio->content_list;
							# my $description = $radio->as_text;
							
							# combine radio name and description
							my $rstring = $station->as_text;
							my $radiostring = $rstring . $description[1];
							# my $radiostring = $rstring . $description;
							
							# the URL of the radio station
							my $link = $station->attr("href");
							
							$log->debug("item: $radiostring -> $link");
			
							# add a station to the menu structure
							push @radio_list_menu, {
								name => $radiostring,
								#name => $description,
								type => 'audio',
								url  => $link,
							};
						}

						# add to category menu
						push @category_menu, {
							name => $category,
							items => \@radio_list_menu,
						};
					}
				}

				$index++;
				
			}
			
			# Here we want ot add the new radio stations to
			# a category menu caled '* Newly Added *'
			# We want to do this by comparing the rss feed items - wich do not
			# contain links to the radio streams - by comparing them with the
			# complete list of radio stations
			
			# all radio stations unsorted
			my @radio_list = $tree->look_down("_tag", "li");
			
			# compare the newly added stations one by one with the list of radio stations
			foreach my $title (@title_list) {
				
				my $ntitle = $title->as_text;

				foreach my $radio (@radio_list) {				
					my $station = $radio->look_down("_tag", "a");
					my $rstring = $station->as_text;
				
					if ($rstring eq $ntitle) {
						$log->debug("match: " . $ntitle);

						# get strings
						my @description = $radio->content_list;
						my $rstring = $station->as_text;
						my $radiostring = $rstring . $description[1];
						my $link = $station->attr("href");
					
						# add a station to the menu structure
						push @newly_added_menu, {
							name => $radiostring,
							type => 'audio',
							url => $link,
						};
					}
				}
			}
			# place the Newly Added menu in front of all categories
			unshift @category_menu, {
				name => '* Newly Added *',
				items => \@newly_added_menu,
			};

			#callback to the server with the new menu
			$callback->(\@category_menu);
		},

		#fetch failure - send back the error
		sub {
			$log->warn("error: $_[1]");
			$callback->([ { name => $_[1], type => 'text' } ]);
		},

	)->get($url);
	
}

1;
